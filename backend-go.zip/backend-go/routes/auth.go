package routes

import (
	"context"
	"encoding/json"
	"fmt"
	"net/http"

	"github.com/Fexaop/mdp-ir-car-parking/query"
	"golang.org/x/oauth2"
)

type AuthRoutes struct {
	GoogleConfig   *oauth2.Config
	UserQueries    UserQueriesInterface
	AuthMiddleware AuthMiddlewareInterface
}

type UserQueriesInterface interface {
	CreateOrIgnoreUser(googleID, email string) error
	CreateOrUpdateUser(googleID, email, name, picture string) error
	GetUserByEmail(email string) (query.UserInfo, error)
	GetUserByGoogleID(googleID string) (query.UserInfo, error)
}

type AuthMiddlewareInterface interface {
	GenerateJWT(uid string) (string, error)
	GetUserIDFromRequest(r *http.Request) (string, error)
}

type LoginRequest struct {
	Email    string `json:"email"`
	Password string `json:"password"`
}

type LoginResponse struct {
	Token string         `json:"token"`
	User  query.UserInfo `json:"user"`
}

func NewAuthRoutes(googleConfig *oauth2.Config, userQueries UserQueriesInterface, authMiddleware AuthMiddlewareInterface) *AuthRoutes {
	return &AuthRoutes{
		GoogleConfig:   googleConfig,
		UserQueries:    userQueries,
		AuthMiddleware: authMiddleware,
	}
}

// Google OAuth login handler
func (ar *AuthRoutes) LoginHandler(w http.ResponseWriter, r *http.Request) {
	// Redirect to Google OAuth
	url := ar.GoogleConfig.AuthCodeURL("state-token")
	http.Redirect(w, r, url, http.StatusTemporaryRedirect)
}

func (ar *AuthRoutes) CallbackHandler(w http.ResponseWriter, r *http.Request) {
	code := r.URL.Query().Get("code")

	token, err := ar.GoogleConfig.Exchange(context.Background(), code)
	if err != nil {
		http.Error(w, "OAuth exchange failed", 500)
		return
	}

	client := ar.GoogleConfig.Client(context.Background(), token)
	resp, err := client.Get("https://www.googleapis.com/oauth2/v2/userinfo")
	if err != nil {
		http.Error(w, "User info failed", 500)
		return
	}
	defer resp.Body.Close()

	var user struct {
		ID      string `json:"id"`
		Email   string `json:"email"`
		Name    string `json:"name"`
		Picture string `json:"picture"`
	}
	json.NewDecoder(resp.Body).Decode(&user)

	err = ar.UserQueries.CreateOrUpdateUser(user.ID, user.Email, user.Name, user.Picture)
	if err != nil {
		http.Error(w, "Database error", 500)
		return
	}

	jwtToken, err := ar.AuthMiddleware.GenerateJWT(user.ID)
	if err != nil {
		http.Error(w, "Token generation failed", 500)
		return
	}

	// Return an HTML page that triggers the deep link
	deepLink := fmt.Sprintf("carparking://callback?token=%s", jwtToken)
	html := fmt.Sprintf(`<!DOCTYPE html>
<html>
<head>
    <title>Login Successful</title>
    <meta charset="UTF-8">
    <style>
        body {
            font-family: system-ui, -apple-system, sans-serif;
            display: flex;
            justify-content: center;
            align-items: center;
            height: 100vh;
            margin: 0;
            background: #f5f5f5;
        }
        .container {
            text-align: center;
            padding: 2rem;
            background: white;
            border-radius: 8px;
            box-shadow: 0 2px 8px rgba(0,0,0,0.1);
        }
        .success {
            color: #16a34a;
            font-size: 1.5rem;
            margin-bottom: 1rem;
        }
        a {
            color: #2563eb;
            text-decoration: none;
            font-weight: 500;
        }
    </style>
</head>
<body>
    <div class="container">
        <div class="success">✓ Login Successful</div>
        <p>Redirecting to app...</p>
        <p><a href="%s" id="deeplink">Click here if not redirected automatically</a></p>
    </div>
    <script>
        window.location.href = "%s";
        setTimeout(function() {
            document.getElementById('deeplink').click();
        }, 1000);
    </script>
</body>
</html>`, deepLink, deepLink)
	
	w.Header().Set("Content-Type", "text/html")
	w.WriteHeader(http.StatusOK)
	w.Write([]byte(html))
}

func (ar *AuthRoutes) ProtectedHandler(w http.ResponseWriter, r *http.Request) {
	// Enable CORS
	w.Header().Set("Access-Control-Allow-Origin", "*")
	w.Header().Set("Access-Control-Allow-Methods", "GET, OPTIONS")
	w.Header().Set("Access-Control-Allow-Headers", "Content-Type, Authorization")

	if r.Method == http.MethodOptions {
		w.WriteHeader(http.StatusOK)
		return
	}

	userID, err := ar.AuthMiddleware.GetUserIDFromRequest(r)
	if err != nil {
		http.Error(w, "Unauthorized", http.StatusUnauthorized)
		return
	}

	// Fetch user from database
	user, err := ar.UserQueries.GetUserByGoogleID(userID)
	if err != nil {
		http.Error(w, "User not found", http.StatusNotFound)
		return
	}

	w.Header().Set("Content-Type", "application/json")
	json.NewEncoder(w).Encode(user)
}